
========================================
==          Installation              ==
========================================

In order to run the software. KinectCpp.dll must be placed in folder "C:\Program Files\Microsoft SDKs\Kinect\v1.8\".
