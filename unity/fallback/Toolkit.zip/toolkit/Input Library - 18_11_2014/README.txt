==================================================
Wheelchair Tank Game Input
==================================================

== Deliverables ==

TankGameInput: A software library that provides input for the tank game using the Kinect.
GameInputTest: An example application for viewing the data from the TankGameInput library.
	       This application requires Visual Studio 2013 and XNA 4.0. See below for information
	       on how to use XNA with VS 2013 and Windows 8.1.



==================================================
Setting up XNA Game Studio 4.0 on Windows 8.1
==================================================

- If the XNA Game Studio setup fails, download and install the Games for Windows � LIVE Redistributable from http://www.xbox.com/en-US/LIVE/PC/DownloadClient
- Then you can run the XNA setup again and it should work.
- XNA Game Studio can only be used with Visual Studio 2010, although there is a non-official project that gives refreshes for VS 2012 and VS 2013 and they work really well. I'd recommend using the VS 2013 refresh.

For using XNA on Windows Phone, check out: http://blogs.msdn.com/b/astebner/archive/2012/02/29/10274694.aspx

- The content project might give you a warning about a mismatch between processor architectures. To solve this warning, open the .contentproj file in Notepad and add the following property to the same property group that contains the XnaFrameworkVersion property:
<PlatformTarget Condition=" '$(PlatformTarget)' == '' ">x86</PlatformTarget>

This solution was given here:
http://blogs.msdn.com/b/astebner/archive/2012/05/03/10300809.aspx
