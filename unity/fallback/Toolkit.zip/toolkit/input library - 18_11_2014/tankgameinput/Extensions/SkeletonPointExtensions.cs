﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Kinect;

using Microsoft.Xna.Framework;


namespace TankGameInput.Extensions
{
    public static class SkeletonPointExtensions
    {

        public static Vector3 ToVector3(this SkeletonPoint point)
        {
            return new Vector3(point.X, point.Y, point.Z);
        }

    }
}
