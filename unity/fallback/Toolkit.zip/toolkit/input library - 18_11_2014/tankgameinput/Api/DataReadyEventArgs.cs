﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Kinect;

namespace TankGameInput
{
    public class DataReadyEventArgs : EventArgs
    {
        internal DataReadyEventArgs(GameInputInfo gameInputInfo, AllFramesReadyEventArgs dataArgs)
        {
            this.gameInputInfo = gameInputInfo;
            this.dataArgs = dataArgs;
            return;
        }


        public GameInputInfo InputInfo { get; private set; }

        public ColorImageFrame OpenColorImageFrame()
        {
            return dataArgs.OpenColorImageFrame();
        }

        public DepthImageFrame OpenDepthImageFrame()
        {
            return dataArgs.OpenDepthImageFrame();
        }

        public SkeletonFrame OpenSkeletonFrame()
        {
            return dataArgs.OpenSkeletonFrame();
        }

        GameInputInfo gameInputInfo;
        AllFramesReadyEventArgs dataArgs;
    }
}
