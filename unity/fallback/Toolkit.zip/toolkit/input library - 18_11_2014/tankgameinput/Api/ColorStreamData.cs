﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Kinect;

namespace TankGameInput
{
    public class ColorStreamData : IDisposable
    {

        public void Dispose()
        {
            if (ColorImageFrame != null)
                ColorImageFrame.Dispose();
        }

        /// <summary>
        /// The color image from the color stream.
        /// </summary>
        public ColorImageFrame ColorImageFrame { get; internal set; }

    }
}
