﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Kinect;

namespace TankGameInput
{
    public class SkeletonStreamData : IDisposable
    {

        public void Dispose()
        {
            if (SkeletonFrame != null)
                SkeletonFrame.Dispose();
        }

        /// <summary>
        /// The skeleton data from the skeleton stream.
        /// </summary>
        public SkeletonFrame SkeletonFrame { get; internal set; }

        /// <summary>
        /// Gives the skeleton index for the tank.
        /// </summary>
        public int TankSkeletonIndex { get; internal set; }

        /// <summary>
        /// Gives the skeleton index for the soldier.
        /// </summary>
        public int SoldierSkeletonIndex { get; internal set; }


    }
}
