﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Kinect;

namespace TankGameInput
{
    public class DepthStreamData : IDisposable
    {

        public void Dispose()
        {
            if (DepthImageFrame != null)
                DepthImageFrame.Dispose();
        }

        /// <summary>
        /// The depth image from the depth stream.
        /// </summary>
        public DepthImageFrame DepthImageFrame { get; internal set; }

        /// <summary>
        /// The player mask of the tank for the depth stream.
        /// </summary>
        public int TankSkeletonMask { get; internal set; }

        /// <summary>
        /// The player mask of the soldier for the depth stream.
        /// </summary>
        public int SoldierSkeletonMask { get; internal set; }

    }
}
