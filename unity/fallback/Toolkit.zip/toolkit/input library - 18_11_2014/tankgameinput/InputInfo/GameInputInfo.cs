﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TankGameInput
{
    /// <summary>
    /// The input info for the game.
    /// </summary>
    public class GameInputInfo
    {

        public GameInputInfo()
        {
            this.TimeStamp = -1;
            this.FrameNumber = -1;

            this.tankInfo = null;
            this.soldierInfo = null;
            return;
        }

        public GameInputInfo(long timeStamp, int frameNumber, TankInfo tankInfo, SoldierInfo soldierInfo)
        {
            this.TimeStamp = timeStamp;
            this.FrameNumber = frameNumber;

            this.tankInfo = tankInfo;
            this.soldierInfo = soldierInfo;
            return;
        }

        public GameInputInfo(GameInputInfo gameInputInfo)
        {
            gameInputInfo.CopyTo(this);
            return;
        }

        public void CopyTo(GameInputInfo gameInputInfo)
        {
            gameInputInfo.TimeStamp = TimeStamp;
            gameInputInfo.FrameNumber = FrameNumber;
            gameInputInfo.tankInfo = this.tankInfo;
            gameInputInfo.soldierInfo = this.soldierInfo;
            return;
        }


        public int FrameNumber { get; private set; }
        public long TimeStamp { get; private set; }

        /// <summary>
        /// Specifies whether the tank input info is available.
        /// </summary>
        public bool IsTankAvailable { get { return tankInfo != null; } }

        /// <summary>
        /// The tank input information.
        /// </summary>
        public TankInfo TankInfo
        {
            get
            {
                if (!IsTankAvailable)
                    throw new MemberAccessException("The tank info is not available.");

                return tankInfo;
            }
        }



        /// <summary>
        /// Specifies whether the soldier input info is available.
        /// </summary>
        public bool IsSoldierAvailable { get { return soldierInfo != null; } }

        /// <summary>
        /// The soldier input information.
        /// </summary>
        public SoldierInfo SoldierInfo
        {
            get
            {
                if (!IsSoldierAvailable)
                    throw new MemberAccessException("The soldier info is not available.");

                return soldierInfo;
            }
        }


        TankInfo tankInfo;
        SoldierInfo soldierInfo;
    }
}
