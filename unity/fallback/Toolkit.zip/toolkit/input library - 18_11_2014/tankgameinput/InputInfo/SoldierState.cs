﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TankGameInput
{

    /// <summary>
    /// The action states of a soldier.
    /// </summary>
    public enum SoldierState
    {
        Walking,
        Peeking,
        Hiding,
        Repairing,
        OutOfFrame
    }
}
