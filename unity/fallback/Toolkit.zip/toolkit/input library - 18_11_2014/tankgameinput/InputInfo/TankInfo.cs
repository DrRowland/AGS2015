﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TankGameInput
{
    /// <summary>
    /// The input information of the tank.
    /// </summary>
    public class TankInfo
    {

        public TankInfo(float speed, float rotation, bool isShooting)
        {
            this.Speed = speed;
            this.Rotation = rotation;
            this.IsShooting = isShooting;
            return;
        }

        public TankInfo(TankInfo tankInfo)
        {
            tankInfo.CopyTo(this);
            return;
        }

        public void CopyTo(TankInfo tankInfo)
        {
            tankInfo.Speed = this.Speed;
            tankInfo.Rotation = this.Rotation;
            tankInfo.IsShooting = this.IsShooting;
            return;
        }

        /// <summary>
        /// The speed of the tank. Ranges from 0 to 1.
        /// </summary>
        public float Speed { get; private set; }

        /// <summary>
        /// The rotation of the tank. Ranges from -30 to +30 degrees, including NaN.
        /// </summary>
        public float Rotation { get; private set; }

        /// <summary>
        /// Specifies whether the tank is shooting.
        /// </summary>
        public bool IsShooting { get; private set; }

    }
}
