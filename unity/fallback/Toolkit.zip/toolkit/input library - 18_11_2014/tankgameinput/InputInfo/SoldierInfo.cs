﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Diagnostics;

namespace TankGameInput
{

    /// <summary>
    /// The input information of the soldier.
    /// </summary>
    public class SoldierInfo
    {

        /// Static Constructors
        #region Static Constructors

        /// <summary>
        /// Creates a SoldierInfo in the Walking state.
        /// </summary>
        public static SoldierInfo CreateSoldierWalking(float position, bool isShooting, bool isWithinRepairingDistance)
        {
            SoldierInfo info = new SoldierInfo();
            info.State = SoldierState.Walking;

            info.position = position;
            info.isShooting = isShooting;
            info.isWithinRepairingDistance = isWithinRepairingDistance;

            return info;
        }

        /// <summary>
        /// Creates a SoldierInfo in the Peeking state.
        /// </summary>
        public static SoldierInfo CreateSoldierPeeking(float headPosition)
        {
            SoldierInfo info = new SoldierInfo();
            info.State = SoldierState.Peeking;

            info.headPosition = headPosition;

            return info;
        }

        /// <summary>
        /// Creates a SoldierInfo in the Hiding state.
        /// </summary>
        public static SoldierInfo CreateSoldierHiding()
        {
            SoldierInfo info = new SoldierInfo();
            info.State = SoldierState.Hiding;

            return info;
        }

        /// <summary>
        /// Creates a SoldierInfo in the Repairing state.
        /// </summary>
        public static SoldierInfo CreateSoldierRepairing()
        {
            SoldierInfo info = new SoldierInfo();
            info.State = SoldierState.Repairing;

            return info;
        }

        /// <summary>
        /// Creates a SoldierInfo in the OutOfFrame state.
        /// </summary>
        public static SoldierInfo CreateSoldierOutOfFrame()
        {
            SoldierInfo info = new SoldierInfo();
            info.State = SoldierState.OutOfFrame;

            return info;
        }

        #endregion


        public SoldierInfo(SoldierInfo soldierInfo)
        {
            soldierInfo.CopyTo(this);
            return;
        }

        
        public void CopyTo(SoldierInfo soldierInfo)
        {
            soldierInfo.State = this.State;

            switch (soldierInfo.State)
            {
                case SoldierState.Walking:
                    soldierInfo.position = this.Position;
                    soldierInfo.isShooting = this.IsShooting;
                    soldierInfo.isWithinRepairingDistance = this.isWithinRepairingDistance;
                    break;

                case SoldierState.Peeking:
                    soldierInfo.headPosition = this.HeadPosition;
                    break;

                case SoldierState.Hiding: break;
                case SoldierState.Repairing: break;
                case SoldierState.OutOfFrame: break;

                default: Debug.Assert(false); break;

            }

            return;
        }


        /// <summary>
        /// The action state of the soldier.
        /// </summary>
        public SoldierState State { get; private set; }

        
        /////////////////////////////////////
        // Walking Info
        /////////////////////////////////////


        /// <summary>
        /// The position of the soldier along the horizontal axis. Ranges from -1 to 1.
        /// </summary>
        public float Position
        {
            get
            {
                if (State != SoldierState.Walking)
                    throw new MemberAccessException("Soldier is in wrong state to access this property.");

                return position;
            }
        }

        /// <summary>
        /// Specifies whether the soldier is shooting.
        /// </summary>
        public bool IsShooting
        {
            get
            {
                if (State != SoldierState.Walking)
                    throw new MemberAccessException("Soldier is in wrong state to access this property.");

                return isShooting;
            }
        }

        /// <summary>
        /// Specifies whether the soldier is within repairing distance of the tank.
        /// </summary>
        public bool IsWithinRepairingDistance
        {
            get
            {
                if (State != SoldierState.Walking)
                    throw new MemberAccessException("Soldier is in wrong state to access this property.");

                return isWithinRepairingDistance;
            }
        }

        /////////////////////////////////////
        // Peeking Info
        /////////////////////////////////////

        /// <summary>
        /// The head position of the soldier.
        /// </summary>
        public float HeadPosition   // left/right/center of tank
        {
            get
            {
                if (State != SoldierState.Peeking)
                    throw new MemberAccessException("Soldier is in wrong state to access this property.");

                return headPosition;
            }
        }


        /////////////////////////////////////
        // Hiding Info
        /////////////////////////////////////

        // None


        /////////////////////////////////////
        // Repairing Info
        /////////////////////////////////////

        // None



        SoldierInfo()
        {
            this.State = SoldierState.Walking;

            position = 0f;
            isShooting = false;
            headPosition = 0f;

            return;
        }

        // Walking Info
        float position;
        bool isShooting;
        bool isWithinRepairingDistance;

        // Peeking Info
        float headPosition;


    }
}
