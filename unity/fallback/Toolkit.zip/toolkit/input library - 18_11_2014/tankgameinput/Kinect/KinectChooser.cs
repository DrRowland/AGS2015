﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using Microsoft.Kinect;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace TankGameInput
{
    
    /// <summary>
    /// This class will pick a kinect sensor if available.
    /// </summary>
    class KinectChooser
    {

        /// <summary>
        /// The status to string mapping.
        /// </summary>
        private readonly Dictionary<KinectStatus, string> statusMap = new Dictionary<KinectStatus, string>();


        /// <summary>
        /// The requested color image format.
        /// </summary>
        public const Microsoft.Kinect.ColorImageFormat ColorImageFormat = Microsoft.Kinect.ColorImageFormat.RgbResolution640x480Fps30;
        public const Microsoft.Kinect.DepthImageFormat DepthImageFormat = Microsoft.Kinect.DepthImageFormat.Resolution640x480Fps30;


        KinectSensor sensor;

        bool colorStreamEnable;
        bool depthStreamEnable;



        /// <summary>
        /// Initializes a new instance of the KinectChooser class.
        /// </summary>
        /// <param name="game">The related game object.</param>
        public KinectChooser()
        {

            KinectSensor.KinectSensors.StatusChanged += this.KinectSensors_StatusChanged;
            this.DiscoverSensor();

            this.statusMap.Add(KinectStatus.Connected, string.Empty);
            this.statusMap.Add(KinectStatus.DeviceNotGenuine, "Device Not Genuine");
            this.statusMap.Add(KinectStatus.DeviceNotSupported, "Device Not Supported");
            this.statusMap.Add(KinectStatus.Disconnected, "Required");
            this.statusMap.Add(KinectStatus.Error, "Error");
            this.statusMap.Add(KinectStatus.Initializing, "Initializing...");
            this.statusMap.Add(KinectStatus.InsufficientBandwidth, "Insufficient Bandwidth");
            this.statusMap.Add(KinectStatus.NotPowered, "Not Powered");
            this.statusMap.Add(KinectStatus.NotReady, "Not Ready");

            colorStreamEnable = false;
            depthStreamEnable = false;

            return;
        }

        

        void sensor_AllFramesReady(object sender, AllFramesReadyEventArgs e)
        {
            if (AllFramesReady != null)
                AllFramesReady(sender, e);

            return;
        }


        

        public CoordinateMapper CoordinateMapper
        {
            get
            {
                if (sensor == null)
                    return null;
                
                return sensor.CoordinateMapper;
            }
        }
        
        /// <summary>
        /// Gets the last known status of the KinectSensor.
        /// </summary>
        public KinectStatus Status { get; private set; }


        public event EventHandler<AllFramesReadyEventArgs> AllFramesReady;
        
        
        public bool ColorStreamEnable
        {
            get
            {
                return colorStreamEnable;
            }

            set
            {
                if (this.Status == KinectStatus.Connected)
                {
                    if(value)
                        this.sensor.ColorStream.Enable(ColorImageFormat);
                    else
                        this.sensor.ColorStream.Disable();
                }

                colorStreamEnable = value;
                return;
            }
        }

        public bool DepthStreamEnable
        {
            get
            {
                return depthStreamEnable;
            }

            set
            {
                if (this.Status == KinectStatus.Connected)
                {
                    if (value)
                        this.sensor.DepthStream.Enable(DepthImageFormat);
                    else
                        this.sensor.DepthStream.Disable();
                }

                depthStreamEnable = value;
                return;
            }
        }

        

        public ColorImageFrame GetColorStreamFrame()
        {
            if (null == sensor || false == sensor.IsRunning || KinectStatus.Connected != sensor.Status)
            {
                return null;
            }

            if (!sensor.ColorStream.IsEnabled)
                return null;

            return sensor.ColorStream.OpenNextFrame(0);
        }


        public DepthImageFrame GetDepthStreamFrame()
        {
            if (null == sensor || false == sensor.IsRunning || KinectStatus.Connected != sensor.Status)
            {
                return null;
            }

            if (!sensor.DepthStream.IsEnabled)
                return null;

            return sensor.DepthStream.OpenNextFrame(0);
        }


        public SkeletonFrame GetSkeletonStreamFrame()
        {
            if (null == sensor || false == sensor.IsRunning || KinectStatus.Connected != sensor.Status)
            {
                return null;
            }

            if (!sensor.SkeletonStream.IsEnabled)
                return null;

            return sensor.SkeletonStream.OpenNextFrame(0);
        }


        /// <summary>
        /// This method will use basic logic to try to grab a sensor.
        /// Once a sensor is found, it will start the sensor with the
        /// requested options.
        /// </summary>
        private void DiscoverSensor()
        {
            // Grab any available sensor
            this.sensor = KinectSensor.KinectSensors.FirstOrDefault();

            if (this.sensor != null)
            {
                this.Status = this.sensor.Status;

                // If this sensor is connected, then enable it
                if (this.Status == KinectStatus.Connected)
                {
                    try
                    {

                        if (colorStreamEnable)
                            this.sensor.ColorStream.Enable(ColorImageFormat);
                        else
                            this.sensor.ColorStream.Disable();
                        
                        if(depthStreamEnable)
                            this.sensor.DepthStream.Enable(DepthImageFormat);
                        else
                            this.sensor.DepthStream.Disable();

                        // Skeleton stream should always be enabled
                        this.sensor.SkeletonStream.Enable();

                        try
                        {
                            this.sensor.AllFramesReady += new EventHandler<AllFramesReadyEventArgs>(sensor_AllFramesReady);
                            //this.sensor.SkeletonFrameReady += new EventHandler<SkeletonFrameReadyEventArgs>(sensor_SkeletonFrameReady);
                            this.sensor.Start();
                        }
                        catch (IOException)
                        {
                            // sensor is in use by another application
                            // will treat as disconnected for display purposes
                            this.sensor = null;
                        }
                    }
                    catch (InvalidOperationException)
                    {
                        // KinectSensor might enter an invalid state while
                        // enabling/disabling streams or stream features.
                        // E.g.: sensor might be abruptly unplugged.
                        this.sensor = null;
                    }
                }
            }
            else
            {
                this.Status = KinectStatus.Disconnected;
            }
        }

        

        /// <summary>
        /// This wires up the status changed event to monitor for 
        /// Kinect state changes.  It automatically stops the sensor
        /// if the device is no longer available.
        /// </summary>
        /// <param name="sender">The sending object.</param>
        /// <param name="e">The event args.</param>
        private void KinectSensors_StatusChanged(object sender, StatusChangedEventArgs e)
        {
            // If the status is not connected, try to stop it
            if (e.Status != KinectStatus.Connected)
            {
                e.Sensor.Stop();
            }

            this.Status = e.Status;
            this.DiscoverSensor();

            return;
        }

    }
}
