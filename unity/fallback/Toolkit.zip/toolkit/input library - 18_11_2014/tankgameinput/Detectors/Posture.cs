﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace TankGameInput
{
    enum Posture
    {
        Standing,
        Seated,
        Unknown
    }
}
