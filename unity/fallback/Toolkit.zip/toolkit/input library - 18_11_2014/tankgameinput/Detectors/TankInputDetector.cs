﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics;

using Microsoft.Xna.Framework;
using Microsoft.Kinect;

using TankGameInput.Extensions;


namespace TankGameInput
{

    class TankInputDetector
    {

        public TankInputDetector()
        {
            return;
        }



        public TankInfo TankInfo { get; private set; }


        public void AddSkeleton(Skeleton tankSkeleton)
        {

            if (tankSkeleton == null || tankSkeleton.TrackingState == SkeletonTrackingState.NotTracked)
            {
                TankInfo = null;
                return;
            }

            // Get whether the skeleton is shooting (hand raised)
            bool isTankShooting = GetIsTankShooting(tankSkeleton);

            // Get the speed of the tank
            float tankSpeed = GetTankSpeed(tankSkeleton);

            // Get the rotation of the tank
            float tankRotation = GetTankRotation(tankSkeleton);


            // Create tank info
            TankInfo tankInfo = new TankInfo(tankSpeed, tankRotation, isTankShooting);

            // Set the tank info
            TankInfo = tankInfo;

            return;
        }


        bool GetIsTankShooting(Skeleton tankSkeleton)
        {
            HandLabel tankHandsRaised = HandRaiseDetector.DetectHandRaise(tankSkeleton);
            bool isTankShooting = (tankHandsRaised != HandLabel.None) && (tankHandsRaised != HandLabel.Unknown);
            return isTankShooting;
        }

        float GetTankSpeed(Skeleton tankSkeleton)
        {
            const float minDepth = 1.5f;
            const float maxDepth = 3.0f; //!! Could get distance of nearest object in the background
            Vector3 tankPosition = tankSkeleton.Joints[JointType.Spine].Position.ToVector3();
            float tankDepth = tankPosition.Z;
            float tankDepthNorm = (tankDepth - minDepth) / (maxDepth - minDepth);
            float tankSpeed = MathHelper.Clamp(tankDepthNorm, 0, 1);
            
            return tankSpeed;
        }

        float GetTankRotation(Skeleton tankSkeleton)
        {
            // Get tank position
            Vector3 tankPosition = tankSkeleton.Joints[JointType.Spine].Position.ToVector3();

            // Get tank angle
            float tankAngle = DirectionExtractor.ExtractAngle(tankSkeleton, new Vector2(tankPosition.X, tankPosition.Z));

            // Convert angle to degrees
            tankAngle = MathHelper.ToDegrees(tankAngle);

            // Clamp angle value
            return MathHelper.Clamp(tankAngle, -30f, 30f);
        }

    }
}
