﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using TankGameInput.Extensions;

using Microsoft.Kinect;
using Microsoft.Xna.Framework;


namespace TankGameInput
{
    /// <summary>
    /// Extracts the direction the skeleton is facing.
    /// </summary>
    class DirectionExtractor
    {
        
        public static Vector2 ExtractDirection(Skeleton skeleton, out bool success)
        {
            // Make sure skeleton is tracked
            if (skeleton.TrackingState == SkeletonTrackingState.NotTracked)
            {
                success = false;
                return Vector2.Zero;
            }

            // Make sure joints are tracked
            Joint[] joints = new[] { JointType.Spine, JointType.HipLeft, JointType.HipRight }.Select(x => skeleton.Joints[x]).ToArray();
            if (joints.Any(x => x.TrackingState != JointTrackingState.Tracked))
            {
                success = false;
                return Vector2.Zero;
            }

            // Convert skeleton points
            Vector3 spine = joints[0].Position.ToVector3();
            Vector3 hipLeft = joints[1].Position.ToVector3();
            Vector3 hipRight = joints[2].Position.ToVector3();

            // Convert direction vector
            Vector3 spineToHipLeft = hipLeft - spine;
            Vector3 spineToHipRight = hipRight - spine;

            Vector3 direction3D = Vector3.Cross(spineToHipRight, spineToHipLeft);

            // Project direction vector onto x-y plane
            Vector2 direction = new Vector2(direction3D.X, direction3D.Z);

            // Normalize vector
            direction.Normalize();

            success = true;
            return direction;
        }


        public static float ExtractAngle(Skeleton skeleton, Vector2 position)
        {
            // Get direction vector
            bool success;
            Vector2 direction = DirectionExtractor.ExtractDirection(skeleton, out success);
            if(!success)
                return float.NaN;

            // Calculate angle
            Vector3 cross = Vector3.Cross(new Vector3(direction, 0), new Vector3(-Vector2.Normalize(position), 0));
            return (float)Math.Asin(cross.Length()) * Math.Sign(cross.Z);
        }

    }
}
