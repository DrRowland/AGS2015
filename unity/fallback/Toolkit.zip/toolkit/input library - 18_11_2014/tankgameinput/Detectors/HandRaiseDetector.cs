﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics;

using Microsoft.Xna.Framework;
using Microsoft.Kinect;

using TankGameInput.Extensions;

namespace TankGameInput
{


    enum HandLabel
    {
        Left,
        Right,
        Both,
        None,
        Unknown
    }


    /// <summary>
    /// Detects whether a skeleton's hand is raised.
    /// </summary>
    static class HandRaiseDetector
    {


        public static HandLabel DetectHandRaise(Skeleton skeleton)
        {
            

            if (skeleton.TrackingState == SkeletonTrackingState.NotTracked)
            {
                //success = false;
                return HandLabel.Unknown;
            }

            if (skeleton.Joints[JointType.HipLeft].TrackingState != JointTrackingState.Tracked &&
                skeleton.Joints[JointType.KneeLeft].TrackingState != JointTrackingState.Tracked)
            {
                //success = false;
                return HandLabel.Unknown;
            }

            
            // Get joint positions
            Vector3 leftHand = skeleton.Joints[JointType.HandLeft].Position.ToVector3();
            Vector3 rightHand = skeleton.Joints[JointType.HandRight].Position.ToVector3();

            Vector3 leftShoulder = skeleton.Joints[JointType.ShoulderLeft].Position.ToVector3();
            Vector3 rightShoulder = skeleton.Joints[JointType.ShoulderRight].Position.ToVector3();


            // A hand is raised if it is above the shoulder
            bool isLeftHandRaised = leftHand.Y > leftShoulder.Y;
            bool isRightHandRaised = rightHand.Y > rightShoulder.Y;


            HandLabel handsRaised;
            if (isLeftHandRaised && isRightHandRaised)
                handsRaised = HandLabel.Both;
            else if (isLeftHandRaised)
                handsRaised = HandLabel.Left;
            else if (isRightHandRaised)
                handsRaised = HandLabel.Right;
            else
                handsRaised = HandLabel.None;

            //success = true;
            return handsRaised;
        }


        

    }
}
