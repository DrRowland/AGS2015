﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Diagnostics;

using Microsoft.Xna.Framework;
using Microsoft.Kinect;

using TankGameInput.Extensions;


namespace TankGameInput
{
    class SoldierInputDetector
    {

        public SoldierInputDetector(KinectChooser kinectChooser)
        {
            this.kinectChooser = kinectChooser;

            soldierSkeletonId = -1;
            InitValues();
            return;
        }


        public CoordinateMapper CoordinateMapper { get; set; }

        public SoldierInfo SoldierInfo { get; private set; }


        public void AddSkeleton(Skeleton soldierSkeleton, Skeleton tankSkeleton)
        {

            SoldierState state;
            bool isSoldierBesideTank = false;
            if (soldierSkeleton == null || soldierSkeleton.TrackingState == SkeletonTrackingState.NotTracked)
            {
                // Get whether skeleton could have walked outside frame
                bool soldierWithinFrame = !isLastSoldierNearFrameBoundary;

                bool isHiding = soldierWithinFrame;

                if (isHiding)
                {
                    state = SoldierState.Hiding;
                }
                else
                {
                    SoldierInfo = null;
                    return;
                }

            }
            else
            {

                // Check if we have a new soldier skeleton
                if (soldierSkeleton.TrackingId != soldierSkeletonId)
                {
                    soldierSkeletonId = soldierSkeleton.TrackingId;
                    InitValues();
                }

                // Get the soldier height if we haven't got it yet
                if (soldierHeight == 0f && soldierSkeleton.Joints[JointType.Head].TrackingState == JointTrackingState.Tracked)
                {
                    soldierHeight = soldierSkeleton.Joints[JointType.Head].Position.Y;
                }

                // Get some extra info about the skeletons //

                // Get whether skeleton could have walked outside frame
                bool soldierWithinFrame = !isLastSoldierNearFrameBoundary;

                bool isSoldierCrouching = IsSkeletonCrouching(soldierSkeleton);

                isSoldierBesideTank = IsSoldierBesideTank(soldierSkeleton, tankSkeleton);


                // Get soldier state //
                if (soldierSkeleton.TrackingState == SkeletonTrackingState.Tracked && !isSoldierCrouching)
                    state = SoldierState.Walking;
                else if (soldierSkeleton.TrackingState == SkeletonTrackingState.Tracked && isSoldierCrouching)
                {
                    // Get whether soldier and tank are near to each other
                    if (isSoldierBesideTank)
                        state = SoldierState.Repairing;
                    else
                        state = SoldierState.Walking;
                }
                else if (soldierSkeleton.TrackingState == SkeletonTrackingState.NotTracked && soldierWithinFrame)
                    state = SoldierState.Hiding;
                else if (soldierSkeleton.TrackingState == SkeletonTrackingState.NotTracked && !soldierWithinFrame)
                    state = SoldierState.OutOfFrame; //!! Probably will never get this because IsSoldierAvailable will just be false.
                else if (soldierSkeleton.TrackingState != SkeletonTrackingState.NotTracked && soldierWithinFrame)
                    state = SoldierState.Peeking;
                else
                {
                    state = SoldierState.OutOfFrame;
                    Debug.Assert(false);
                }

            }


            // Create soldier info
            SoldierInfo soldierInfo;
            switch (state)
            {
                case SoldierState.Walking:
                    {
                        // Get whether the skeleton is shooting (hand raised)
                        HandLabel soldierHandsRaised = HandRaiseDetector.DetectHandRaise(soldierSkeleton);
                        bool isShooting = (soldierHandsRaised != HandLabel.None) && (soldierHandsRaised != HandLabel.Unknown);

                        // Get soldier position
                        //!! Right now, this code assumes a rectanglar field on the floor as the bounds of the game. Another way would be to
                        //!!      make the field of view of the camera as the bounds. This can be done by using SkeletonToDepthMap().
                        Vector3 skeletonPosition = soldierSkeleton.Position.ToVector3();
                        float position = MathHelper.Clamp(skeletonPosition.X, -1f, 1f);

                        //!! We could also do some smoothing of the position value (or use the torso point instead of the skeleton position) if it is too noisy.

                        soldierInfo = SoldierInfo.CreateSoldierWalking(position, isShooting, isSoldierBesideTank);

                        break;
                    }

                case SoldierState.Peeking:
                    {
                        //!! Could do sanity check on soldier skeleton or see if the two skeletons are touching to see if the soldier is peeking.
                        //!!    Check height of tank skeleton (or size of tank blob) to see if the two skeletons merged into one (this would be peeking from center).

                        // Get position of head
                        //!! Could do left/right/center if the position is unreliable.
                        Vector3 headPosition = soldierSkeleton.Joints[JointType.Head].Position.ToVector3();
                        float headPositionX = headPosition.X;

                        soldierInfo = SoldierInfo.CreateSoldierPeeking(headPositionX);

                        break;
                    }

                case SoldierState.Hiding:
                    soldierInfo = SoldierInfo.CreateSoldierHiding();
                    break;

                case SoldierState.Repairing:
                    soldierInfo = SoldierInfo.CreateSoldierRepairing();
                    break;

                case SoldierState.OutOfFrame:
                    soldierInfo = SoldierInfo.CreateSoldierOutOfFrame();
                    break;

                default: soldierInfo = null; Debug.Assert(false); break;
            }


            // Update if skeleton is near frame boundary
            if(soldierSkeleton != null && soldierSkeleton.TrackingState != SkeletonTrackingState.NotTracked)
                isLastSoldierNearFrameBoundary = IsSkeletonNearFrameBoundary(soldierSkeleton);

            // Set the soldier info
            SoldierInfo = soldierInfo;

            return;
        }


        void InitValues()
        {
            soldierHeight = 0f;
            isLastSoldierNearFrameBoundary = true;
            return;
        }


        bool IsSkeletonNearFrameBoundary(Skeleton skeleton)
        {
            float frameBoundaryLeft = 50f; //0 + 50
            float frameBoundaryRight = 590f; //640 - 50

            if (skeleton.TrackingState == SkeletonTrackingState.NotTracked)
                return true;

            // Map skeleton to a 2D plane
            Vector2 skeletonPosition = SkeletonToDepthMap(skeleton.Position);

            // Check to see if the skeleton is outside the frame
            return (skeletonPosition.X < frameBoundaryLeft) || (skeletonPosition.X > frameBoundaryRight);
        }


        bool IsSoldierBesideTank(Skeleton soldierSkeleton, Skeleton tankSkeleton)
        {
            const float nearDistanceX = 0.3f;
            const float farDistanceX = 0.6f;

            const float inFrontDistanceZ = 0.5f;
            const float inBehindDistanceZ = 1.0f;

            if (soldierSkeleton == null || tankSkeleton == null)
                return false;

            if (soldierSkeleton.TrackingState == SkeletonTrackingState.NotTracked || tankSkeleton.TrackingState == SkeletonTrackingState.NotTracked)
                return false;


            Vector3 tankPosition = tankSkeleton.Position.ToVector3();
            //Vector3 tankPosition = new Vector3(0f, 2f, 2.5f);

            // Check if skeleton is along the same Z value as the tank
            float inFrontThreshold = tankPosition.Z - inFrontDistanceZ;
            float inBehindThreshold = tankPosition.Z + inBehindDistanceZ;
            bool isBesideTankZ = (soldierSkeleton.Position.Z > inFrontThreshold) && (soldierSkeleton.Position.Z < inBehindThreshold);

            // Check if skeleton is beside tank. not in front, behind or too far away
            float distX = Math.Abs(soldierSkeleton.Position.X - tankPosition.X);
            bool isBesideTankX = (distX > nearDistanceX) && (distX < farDistanceX);

            // Get skeleton positions
            return isBesideTankZ && isBesideTankX;
        }

        bool IsSkeletonCrouching(Skeleton skeleton)
        {
            const float scale = 0.75f; // percentage of original height

            if (skeleton.Joints[JointType.Head].TrackingState == JointTrackingState.NotTracked)
                return false;

            return skeleton.Joints[JointType.Head].Position.Y < soldierHeight * scale;
        }


        /// <summary>
        /// This method maps a SkeletonPoint to the depth frame.
        /// </summary>
        /// <param name="point">The SkeletonPoint to map.</param>
        /// <returns>A Vector2 of the location on the depth frame.</returns>
        private Vector2 SkeletonToDepthMap(SkeletonPoint point)
        {
            if (null == kinectChooser.CoordinateMapper || kinectChooser.CoordinateMapper == null)
                return Vector2.Zero;

            // This is used to map a skeleton point to the depth image location
            var depthPt = kinectChooser.CoordinateMapper.MapSkeletonPointToDepthPoint(point, KinectChooser.DepthImageFormat);
            return new Vector2(depthPt.X, depthPt.Y);
        }



        readonly KinectChooser kinectChooser;

        bool isLastSoldierNearFrameBoundary;
        float soldierHeight;
        int soldierSkeletonId;

    }
}
