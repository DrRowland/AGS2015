﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;

using Microsoft.Kinect;
using TankGameInput.Extensions;

namespace TankGameInput
{

    /// <summary>
    /// Detects whether a skeleton is sitting.
    /// </summary>
    static class SittingDetector
    {


        public static Posture DetectSitting(Skeleton skeleton) //, out bool success)
        {
            // Improvements:
            // Can use right side to confirm
            // Can use chair to see if sitting in a chair or just crouching
            // If we can't get the position (because of no tracked points) then we can have SkeletonEnhancer postpone the detection to next frame

            if (skeleton.TrackingState == SkeletonTrackingState.NotTracked)
            {
                //success = false;
                return Posture.Unknown;
            }

            if (skeleton.Joints[JointType.HipLeft].TrackingState != JointTrackingState.Tracked &&
                skeleton.Joints[JointType.KneeLeft].TrackingState != JointTrackingState.Tracked)
            {
                //success = false;
                return Posture.Unknown;
            }

            
            // Get positions
            Vector3 leftHip = skeleton.Joints[JointType.HipLeft].Position.ToVector3();
            Vector3 leftKnee = skeleton.Joints[JointType.KneeLeft].Position.ToVector3();

            // Get vectors
            Vector3 thighUnitVector = Vector3.Normalize(leftKnee - leftHip);

            // Get how horizontal the thigh is.
            // Value is between 0 and 1.
            // The higher the value, the more sitting.
            //!! Technically, we should consider anything above horizontal as sitting as well! (dot product > 0)
            float horizontal = 1 - Math.Abs(Vector3.Dot(thighUnitVector, Vector3.Up));

            // Threshold the value to determine what is sitting
            bool isSitting = horizontal > 0.2f;

            //success = true;
            return isSitting ? Posture.Seated : Posture.Standing;
        }


        

    }
}
