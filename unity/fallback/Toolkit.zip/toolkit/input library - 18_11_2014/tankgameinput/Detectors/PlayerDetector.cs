﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Kinect;

using TankGameInput.Extensions;


namespace TankGameInput
{

    /// <summary>
    /// Determines which skeleton is the tank and which is the soldier.
    /// </summary>
    class PlayerDetector
    {


        public PlayerDetector()
        {

            oldSoldierTrackingId = -1;
            return;
        }



        public bool IsTankAvailable { get; private set; }
        public bool IsSoldierAvailable { get; private set; }

        public int TankSkeletonIndex { get; private set; }
        public int SoldierSkeletonIndex { get; private set; }



        /// <summary>
        /// Adds skeletons for detection.
        /// This function does not copy the skeletons in any way.
        /// </summary>
        /// <param name="skeleton"></param>
        public void AddSkeletons(Skeleton[] skeletons, Posture[] postures)
        {

            // The tank and soldier will be the closest sitting and standing skeletons to the Kinect


            // Get distance of skeletons from the Kinect
            Vector3[] positions = Array.ConvertAll(skeletons, x => x.Position.ToVector3());
            float[] distances = Array.ConvertAll(positions, x => x.Length());


            // Find the soldier skeleton //

            // First look for a crouching soldier
            int soldierSkeletonIndex = -1;
            {
                Skeleton soldierSkeleton = skeletons.FirstOrDefault(x => x.TrackingId == oldSoldierTrackingId && x.TrackingState != SkeletonTrackingState.NotTracked);
                if (soldierSkeleton == null)
                {
                    // No crouching soldier found, so look for the closest standing soldier
                    float soldierSkeletonDist = float.PositiveInfinity;

                    for (int i = 0; i < skeletons.Length; i++)
                    {
                        if (postures[i] == Posture.Standing && distances[i] < soldierSkeletonDist)
                        {
                            soldierSkeletonIndex = i;
                            soldierSkeletonDist = distances[i];
                        }
                    }

                }
                else
                {
                    soldierSkeletonIndex = Array.FindIndex(skeletons,x => x.TrackingId == soldierSkeleton.TrackingId);
                }
            }


            // Find the tank skeleton //

            // Get the closest sitting skeleton to the Kinect
            int tankSkeletonIndex = -1;
            float tankSkeletonDist = float.PositiveInfinity;

            for (int i = 0; i < skeletons.Length; i++)
            {
                if (postures[i] == Posture.Seated && distances[i] < tankSkeletonDist && i != soldierSkeletonIndex)
                {
                    tankSkeletonIndex = i;
                    tankSkeletonDist = distances[i];
                }
            }


            // Set skeletons
            IsTankAvailable = (tankSkeletonIndex != -1);
            IsSoldierAvailable = (soldierSkeletonIndex != -1);

            TankSkeletonIndex = tankSkeletonIndex;
            SoldierSkeletonIndex = soldierSkeletonIndex;

            if (soldierSkeletonIndex != -1)
                oldSoldierTrackingId = skeletons[soldierSkeletonIndex].TrackingId;
            else
                oldSoldierTrackingId = -1;

            return;
        }



        int oldSoldierTrackingId;

    }
}
