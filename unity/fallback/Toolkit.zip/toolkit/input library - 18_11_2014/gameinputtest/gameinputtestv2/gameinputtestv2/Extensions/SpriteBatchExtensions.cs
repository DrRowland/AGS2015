﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using System.Diagnostics;

namespace TankGameInputExample.Extensions
{

    public enum HorizAlignment
    {
        Center,
        Left,
        Right
    }

    public enum VertAlignment
    {
        Top,
        Center,
        Bottom
    }


    public static class SpriteBatchExtensions
    {

        public static void DrawString(this SpriteBatch spriteBatch, SpriteFont font, String text, Vector2 position, Color color, HorizAlignment horizAlign, VertAlignment vertAlign)
        {
            Vector2 size = font.MeasureString(text);
            Vector2 origin = size * 0.5f;
            
            switch (horizAlign)
            {
                case HorizAlignment.Left:
                    origin.X = 0;
                    break;

                case HorizAlignment.Center:
                    origin.X = size.X * 0.5f;
                    break;

                case HorizAlignment.Right:
                    origin.X = size.X;
                    break;

                default: Debug.Assert(false); break;

            }

            switch (vertAlign)
            {
                case VertAlignment.Top:
                    origin.Y = 0;
                    break;

                case VertAlignment.Center:
                    origin.Y = size.Y * 0.5f;
                    break;

                case VertAlignment.Bottom:
                    origin.Y = size.Y;
                    break;

                default: Debug.Assert(false); break;

            }


            spriteBatch.DrawString(font, text, position, color, 0f, origin, 1f, SpriteEffects.None, 0f);

            return;
        }

    }
}
