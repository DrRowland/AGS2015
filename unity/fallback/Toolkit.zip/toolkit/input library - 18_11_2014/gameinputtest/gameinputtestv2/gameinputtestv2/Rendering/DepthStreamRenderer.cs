﻿using Microsoft.Kinect;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;


namespace TankGameInputExample
{
    
    /// <summary>
    /// This class renders the current depth stream frame.
    /// </summary>
    public class DepthStreamRenderer
    {

        

        /// <summary>
        /// The depth frame as a texture.
        /// </summary>
        private Texture2D depthTexture;
        
        /// <summary>
        /// This Xna effect is used to convert the depth to RGB color information.
        /// </summary>
        private Effect kinectDepthVisualizer;

        Vector2 size;

        readonly Game game;

        /// <summary>
        /// Initializes a new instance of the DepthStreamRenderer class.
        /// </summary>
        /// <param name="game">The related game object.</param>
        public DepthStreamRenderer(Game game)
        {
            this.game = game;
            this.size = new Vector2(160, 120);

            return;
        }

        public TankGameInput.SoldierInfo SoldierInfo { get; set; }

        /// <summary>
        /// Initializes the necessary children.
        /// </summary>
        public void Initialize()
        {
            this.size = new Vector2(game.GraphicsDevice.Viewport.Width, game.GraphicsDevice.Viewport.Height);

            return;
        }


        /// <summary>
        /// This method loads the Xna effect.
        /// </summary>
        public void LoadContent()
        {
            // This effect is used to convert depth data to color for display
            this.kinectDepthVisualizer = game.Content.Load<Effect>("KinectDepthVisualizer");
        }

        /// <summary>
        /// The update method where the new depth frame is retrieved.
        /// </summary>
        /// <param name="gameTime">The elapsed game time.</param>
        public void Update(GameTime gameTime)
        {

            return;
        }


        /// <summary>
        /// This method renders the color and skeleton frame.
        /// </summary>
        /// <param name="gameTime">The elapsed game time.</param>
        public void Draw(GameTime gameTime)
        {

            // Get depth data
            short[] depthData = GameInfo.DepthData;

            // Sometimes we get a null frame back if no data is ready
            if (null == depthData || depthData.Length == 0)
                return;

            // Reallocate texture if necessary
            if (null == this.depthTexture || this.depthTexture.Width != GameInfo.DepthFrameWidth || this.depthTexture.Height != GameInfo.DepthFrameHeight)
            {

                this.depthTexture = new Texture2D(
                    game.GraphicsDevice,
                    GameInfo.DepthFrameWidth,
                    GameInfo.DepthFrameHeight,
                    false,
                    SurfaceFormat.Bgra4444);
            }

            // Get the soldier state index
            int soldierStateIndex;
            if (SoldierInfo != null)
            {
                soldierStateIndex = (int)SoldierInfo.State;
                if (SoldierInfo.State == TankGameInput.SoldierState.Walking && SoldierInfo.IsWithinRepairingDistance)
                    soldierStateIndex = 5; //max value of SoldierState + 1
            }
            else
            {
                soldierStateIndex = 0;
            }

            // Draw depth texture
            {

                this.depthTexture.SetData<short>(depthData);

                // Set the shader parameters
                kinectDepthVisualizer.Parameters["xTankId"].SetValue(GameInfo.TankSkeletonMask);
                kinectDepthVisualizer.Parameters["xSoldierId"].SetValue(GameInfo.SoldierSkeletonMask);
                kinectDepthVisualizer.Parameters["xSoldierState"].SetValue(soldierStateIndex);

                // Draw the depth image
                GameInfo.SpriteBatch.Begin(SpriteSortMode.Immediate, null, null, null, null, this.kinectDepthVisualizer);
                GameInfo.SpriteBatch.Draw(this.depthTexture, Vector2.Zero, Color.White);
                GameInfo.SpriteBatch.End();

            }


            return;
        }


    }
}
