﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;

using Microsoft.Kinect;

using TankGameInputExample.Extensions;

using TankGameInput;


namespace TankGameInputExample
{

    /// <summary>
    /// This class is responsible for rendering the annotations on the skeleton stream.
    /// </summary>
    public class AnnotationStreamRenderer
    {

        /// <summary>
        /// Whether the rendering has been initialized.
        /// </summary>
        private bool initialized;
        private bool contentLoaded;


        /// <summary>
        /// This is the font for the annotations.
        /// </summary>
        private SpriteFont font16;
        private SpriteFont font32;


        Vector2 size;

        readonly Game game;


        /// <summary>
        /// Initializes a new instance of the AnnotationStreamRenderer class.
        /// </summary>
        /// <param name="game">The related game object.</param>
        public AnnotationStreamRenderer(Game game)
        {
            this.game = game;

            initialized = false;
            contentLoaded = false;

            return;
        }


        public GameInputInfo GameInputInfo { get; set; }
        public bool IsVerboseMode { get; set; }


        /// <summary>
        /// This method initializes necessary values.
        /// </summary>
        public void Initialize()
        {
            this.size = new Vector2(game.GraphicsDevice.Viewport.Width, game.GraphicsDevice.Viewport.Height);
            this.initialized = true;

            return;
        }


        /// <summary>
        /// This method loads the textures and sets the origin values.
        /// </summary>
        public void LoadContent()
        {
            this.font16 = game.Content.Load<SpriteFont>("Segoe16");
            this.font32 = game.Content.Load<SpriteFont>("Segoe32");

            contentLoaded = true;
            return;
        }


        public void Update(GameTime gameTime)
        {
            return;
        }


        /// <summary>
        /// This method draws the skeleton frame data.
        /// </summary>
        /// <param name="gameTime">The elapsed game time.</param>
        public void Draw(GameTime gameTime)
        {
            // If the joint texture isn't loaded, load it now
            if (!contentLoaded)
                this.LoadContent();


            // Get the skeleton data
            Skeleton[] skeletonData = GameInfo.SkeletonData;

            // If we don't have data, lets leave
            if (null == skeletonData)
                return;


            if (!this.initialized)
                this.Initialize();



            // Get game input info
            // Give skeleton frame to GameInput
            
            // Draw annotations
            Skeleton tankSkeleton = GameInfo.TankSkeletonIndex != -1 ? GameInfo.SkeletonData[GameInfo.TankSkeletonIndex] : null;
            Skeleton soldierSkeleton = GameInfo.SoldierSkeletonIndex != -1 ? GameInfo.SkeletonData[GameInfo.SoldierSkeletonIndex] : null;

            if (GameInputInfo != null)
            {
                DrawTankAnnotations(GameInputInfo, tankSkeleton);
                DrawSoldierAnnotations(GameInputInfo, soldierSkeleton, tankSkeleton);
            }
            
            return;
        }



        /// <summary>
        /// Draws the tank annotations. There are two places to write text.
        /// 1. Above the tank's head.
        /// 2. At the tank's torso. (verbose mode)
        /// </summary>
        /// <param name="inputInfo"></param>
        /// <param name="skeleton"></param>
        void DrawTankAnnotations(GameInputInfo inputInfo, Skeleton skeleton)
        {

            if (!inputInfo.IsTankAvailable)
                return;
            

            // Get text properties //

            TankInfo tankInfo = inputInfo.TankInfo;

            // Get text for above tank's head
            String labelText;
            Vector2 labelPosition;
            if (skeleton != null && skeleton.TrackingState == SkeletonTrackingState.Tracked)
            {
                // Get text
                labelText = tankInfo.IsShooting ? "!Tank!" : "Tank";

                // Get position
                labelPosition = SkeletonToDepthMap(skeleton.Joints[JointType.Head].Position);
                labelPosition.Y -= 20;
            }
            else
            {
                labelText = "";
                labelPosition = Vector2.Zero;
            }


            // Get state text for soldier's torso
            String stateText;
            Vector2 statePosition;
            if (skeleton != null && skeleton.TrackingState != SkeletonTrackingState.NotTracked)
            {
                // Get text
                stateText = tankInfo.Speed + "\n" + tankInfo.Rotation + "\n" + tankInfo.IsShooting;

                // Get position
                statePosition = SkeletonToDepthMap(skeleton.Joints[JointType.Spine].Position);
                statePosition.Y += 20;

            }
            else
            {
                stateText = "";
                statePosition = Vector2.Zero;
            }


            // Draw text //
            GameInfo.SpriteBatch.Begin();
            {
                // Draw label
                GameInfo.SpriteBatch.DrawString(this.font16, labelText, labelPosition, Color.Red, HorizAlignment.Center, VertAlignment.Bottom);

                // Draw state
                if (IsVerboseMode)
                    GameInfo.SpriteBatch.DrawString(this.font32, stateText, statePosition, Color.Black, HorizAlignment.Center, VertAlignment.Top);

            }
            GameInfo.SpriteBatch.End();

            return;
        }


        /// <summary>
        /// Draws the soldier annotations. There are three places to write text.
        /// 1. Above the soldier's head.
        /// 2. At the soldier's torso. (verbose mode)
        /// 3. As a header at the top of the screen.
        /// </summary>
        /// <param name="inputInfo"></param>
        /// <param name="skeleton"></param>
        /// <param name="tankSkeleton"></param>
        void DrawSoldierAnnotations(GameInputInfo inputInfo, Skeleton skeleton, Skeleton tankSkeleton)
        {

            if (!inputInfo.IsSoldierAvailable)
                return;


            // Get text properties //

            SoldierInfo soldierInfo = inputInfo.SoldierInfo;
            if (soldierInfo == null)
                return;


            // Get text for above soldier's head
            String labelText = "Soldier";
            Vector2 labelPosition;
            if (skeleton != null && skeleton.TrackingState == SkeletonTrackingState.Tracked)
            {
                // Get text
                if (soldierInfo.State == SoldierState.Walking && soldierInfo.IsShooting)
                    labelText = "!Soldier!";

                // Get position
                labelPosition = SkeletonToDepthMap(skeleton.Joints[JointType.Head].Position);
                labelPosition.Y -= 20;
            }
            else
            {
                labelText = "";
                labelPosition = Vector2.Zero;
            }


            // Get state text for soldier's torso
            String stateText;
            Vector2 statePosition;
            if (skeleton != null && skeleton.TrackingState != SkeletonTrackingState.NotTracked)
            {
                // Get text
                //stateText = soldierInfo.State.ToString();
                Vector2 skelPos = SkeletonToDepthMap(skeleton.Position);
                //stateText = String.Format("{0:F4}\n{1:F4}", skeleton.Position.X, skeleton.Position.Z);
                stateText = String.Format("{0:F4}\n{1:F4}", skelPos.X, skelPos.Y);

                // Get position
                statePosition = SkeletonToDepthMap(skeleton.Joints[JointType.Spine].Position);
                statePosition.Y += 20;

            }
            else
            {
                stateText = "";
                statePosition = Vector2.Zero;
            }


            // Get header text for the top of the screen
            String headerText;
            Vector2 headerPosition;
            {
                // Get text
                headerText = (soldierInfo.State == SoldierState.Hiding) ? "Soldier Hiding" : "";
                //headerText = (soldierInfo.State == SoldierState.Walking) ? soldierInfo.Position.ToString() : "";
                
                // Get position
                headerPosition = new Vector2(640 / 2, 60);
            }


            // Draw text //
            GameInfo.SpriteBatch.Begin();
            {
                // Draw label
                GameInfo.SpriteBatch.DrawString(this.font16, labelText, labelPosition, Color.Red, HorizAlignment.Center, VertAlignment.Bottom);

                // Draw state
                if (IsVerboseMode)
                    GameInfo.SpriteBatch.DrawString(this.font32, stateText, statePosition, Color.Black, HorizAlignment.Center, VertAlignment.Top);

                //
                /*
                {
                    if (soldierInfo.State == SoldierState.Walking)
                    {
                        Vector2 position = new Vector2((soldierInfo.Position / 2f + 0.5f) * 640f, 60f);
                        GameInfo.SpriteBatch.DrawString(this.font32, "H", position, Color.Red, HorizAlignment.Center, VertAlignment.Top);
                    }
                }
                */

                // Draw header
                GameInfo.SpriteBatch.DrawString(this.font32, headerText, headerPosition, Color.Red, HorizAlignment.Center, VertAlignment.Bottom);
            }
            GameInfo.SpriteBatch.End();

            return;
        }





        /// <summary>
        /// This method maps a SkeletonPoint to the depth frame.
        /// </summary>
        /// <param name="point">The SkeletonPoint to map.</param>
        /// <returns>A Vector2 of the location on the depth frame.</returns>
        private Vector2 SkeletonToDepthMap(SkeletonPoint point)
        {
            if (null == GameInfo.GameInput || GameInfo.GameInput.CoordinateMapper == null)
                return Vector2.Zero;

            // This is used to map a skeleton point to the depth image location
            var depthPt = GameInfo.GameInput.CoordinateMapper.MapSkeletonPointToDepthPoint(point, GameInfo.DepthImageFormat);
            return new Vector2(depthPt.X, depthPt.Y);
        }


    }
}
