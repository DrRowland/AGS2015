﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Microsoft.Kinect;

using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using TankGameInput;

namespace TankGameInputExample
{
    static class GameInfo
    {

        static GameInfo()
        {
            TankSkeletonMask = -1;
            SoldierSkeletonMask = -1;

            TankSkeletonIndex = -1;
            SoldierSkeletonIndex = -1;

            return;
        }

        public static SpriteBatch SpriteBatch { get; set; }
        public static GameInput GameInput { get; set; }

        /// <summary>
        /// The last frame of depth data.
        /// </summary>
        public static short[] DepthData { get; set; }
        public static DepthImageFormat DepthImageFormat { get; set; }
        public static int DepthFrameWidth { get; set; }
        public static int DepthFrameHeight { get; set; }

        public static int TankSkeletonMask { get; set; }
        public static int SoldierSkeletonMask { get; set; }

        /// <summary>
        /// The last frame of skeleton data.
        /// </summary>
        public static Skeleton[] SkeletonData { get; set; }

        public static int TankSkeletonIndex { get; set; }
        public static int SoldierSkeletonIndex { get; set; }

    }
}
