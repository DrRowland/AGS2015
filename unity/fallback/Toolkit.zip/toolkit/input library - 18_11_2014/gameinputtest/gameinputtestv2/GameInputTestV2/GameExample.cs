///////////////////////////////////////////////////////////////////////
// This example is based on the XnaBasics example from
// the Kinect v1 samples made by Microsoft.
///////////////////////////////////////////////////////////////////////


using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Audio;
using Microsoft.Xna.Framework.Content;
using Microsoft.Xna.Framework.GamerServices;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Media;

using Microsoft.Kinect;

using TankGameInput;

namespace TankGameInputExample
{

    /// <summary>
    /// The main game implementation.
    /// </summary>
    public class GameExample : Microsoft.Xna.Framework.Game
    {
        /// <summary>
        /// This is used to adjust the window size.
        /// </summary>
        private const int scaleMultiplier = 2;
        private const int width = 640 * scaleMultiplier;
        private const int height = 480 * scaleMultiplier;


        /// <summary>
        /// The graphics device manager provided by Xna.
        /// </summary>
        private readonly GraphicsDeviceManager graphics;
        

        /// <summary>
        /// This manages the rendering of the depth stream.
        /// </summary>
        private readonly DepthStreamRenderer depthStream;

        /// <summary>
        /// This manages the rendering of the skeleton stream.
        /// </summary>
        private readonly SkeletonStreamRenderer skeletonStream;

        /// <summary>
        /// This manages the annotations of the skeleton stream.
        /// </summary>
        private readonly AnnotationStreamRenderer annotationStream;


        /// <summary>
        /// This is the viewport of the stream.
        /// </summary>
        private readonly Rectangle viewPortRectangle;


        /// <summary>
        /// Player input for the game.
        /// </summary>
        readonly GameInput gameInput;

        /// <summary>
        /// Specifies whether to draw extra information.
        /// </summary>
        const bool isVerboseMode = false;


        /// <summary>
        /// The back buffer which is the same size as the Kinect frames and is where the depth and skeleton frames are drawn.
        /// </summary>
        private RenderTarget2D backBuffer;

        GameInputInfo gameInputInfo;


        /// <summary>
        /// Initializes a new instance of the XnaBasics class.
        /// </summary>
        public GameExample()
        {
            this.IsFixedTimeStep = false;
            this.IsMouseVisible = true;
            this.Window.Title = "Xna Basics";

            // This sets the width to the desired width
            // It also forces a 4:3 ratio for height
            // Adds 110 for header/footer
            this.graphics = new GraphicsDeviceManager(this);
            this.graphics.PreferredBackBufferWidth = width;
            this.graphics.PreferredBackBufferHeight = height;
            this.graphics.PreparingDeviceSettings += this.GraphicsDevicePreparingDeviceSettings;
            this.graphics.SynchronizeWithVerticalRetrace = true;
            this.viewPortRectangle = new Rectangle(0, 0, width, height);

            Content.RootDirectory = "Content";


            // Create the depth stream renderer
            this.depthStream = new DepthStreamRenderer(this);

            // Create the skeleton stream renderer
            this.skeletonStream = new SkeletonStreamRenderer(this);
            this.skeletonStream.IsVerboseMode = isVerboseMode;

            // Create the annotation stream renderer
            this.annotationStream = new AnnotationStreamRenderer(this);
            this.annotationStream.IsVerboseMode = isVerboseMode;

            // Create the game input
            gameInput = new GameInput();
            gameInput.DepthStreamEnable = true;
            GameInfo.GameInput = gameInput;
            
            return;
        }

        /// <summary>
        /// Loads the Xna related content.
        /// </summary>
        protected override void LoadContent()
        {
            GameInfo.SpriteBatch = new SpriteBatch(this.GraphicsDevice);

            // Load content for streams
            depthStream.LoadContent();
            skeletonStream.LoadContent();
            annotationStream.LoadContent();

            base.LoadContent();

            return;
        }

        /// <summary>
        /// Initializes class and components
        /// </summary>
        protected override void Initialize()
        {

            GameInfo.DepthFrameWidth = 640;
            GameInfo.DepthFrameHeight = 480;

            // Initialize streams
            depthStream.Initialize();
            skeletonStream.Initialize();
            annotationStream.Initialize();


            base.Initialize();
            return;
        } 

        /// <summary>
        /// This method updates the game state. Including monitoring
        /// keyboard state and the transitions.
        /// </summary>
        /// <param name="gameTime">The elapsed game time.</param>
        protected override void Update(GameTime gameTime)
        {

            // Get Kinect data
            GetFrames(gameInput);
            

            // Send the game info to the renderers
            if (gameInputInfo != null && gameInputInfo.IsSoldierAvailable)
                depthStream.SoldierInfo = gameInputInfo.SoldierInfo;
            else
                depthStream.SoldierInfo = null;


            annotationStream.GameInputInfo = gameInputInfo;

            // Update streams
            depthStream.Update(gameTime);
            skeletonStream.Update(gameTime);
            annotationStream.Update(gameTime);

            base.Update(gameTime);
            return;
        }

        /// <summary>
        /// This method renders the current state.
        /// </summary>
        /// <param name="gameTime">The elapsed game time.</param>
        protected override void Draw(GameTime gameTime)
        {
            // Clear the screen
            GraphicsDevice.Clear(Color.White);

            // Reallocate textures if necessary
            if (null == this.backBuffer || this.backBuffer.Width != GameInfo.DepthFrameWidth || this.backBuffer.Height != GameInfo.DepthFrameHeight)
            {
                this.backBuffer = new RenderTarget2D(
                    GraphicsDevice,
                    GameInfo.DepthFrameWidth,
                    GameInfo.DepthFrameHeight,
                    false,
                    SurfaceFormat.Color,
                    DepthFormat.None,
                    GraphicsDevice.PresentationParameters.MultiSampleCount,
                    RenderTargetUsage.PreserveContents);
            }

            // Draw depth and skeleton streams onto a back buffer which is the same size as the frames coming from the Kinect
            {

                // Set the backbuffer and clear
                GraphicsDevice.SetRenderTarget(this.backBuffer);
                GraphicsDevice.Clear(ClearOptions.Target, Color.Black, 1.0f, 0);

                depthStream.Draw(gameTime);
                skeletonStream.Draw(gameTime);
                annotationStream.Draw(gameTime);

                // Reset the render target and prepare to draw scaled image
                GraphicsDevice.SetRenderTarget(null);

            }
            
            // Draw scaled image
            GameInfo.SpriteBatch.Begin();
            GameInfo.SpriteBatch.Draw(
                this.backBuffer,
                new Rectangle((int)0, (int)0, (int)GraphicsDevice.Viewport.Width, (int)GraphicsDevice.Viewport.Height),
                null,
                Color.White);
            GameInfo.SpriteBatch.End();

            base.Draw(gameTime);
            return;
        }

        /// <summary>
        /// This method ensures that we can render to the back buffer without
        /// losing the data we already had in our previous back buffer.  This
        /// is necessary for the SkeletonStreamRenderer.
        /// </summary>
        /// <param name="sender">The sending object.</param>
        /// <param name="e">The event args.</param>
        private void GraphicsDevicePreparingDeviceSettings(object sender, PreparingDeviceSettingsEventArgs e)
        {
            // This is necessary because we are rendering to back buffer/render targets and we need to preserve the data
            e.GraphicsDeviceInformation.PresentationParameters.RenderTargetUsage = RenderTargetUsage.PreserveContents;
        }



        void GetFrames(GameInput gameInput)
        {

            // If the sensor is not found, not running, or not connected, stop now
            if (null == gameInput || gameInput.KinectStatus != KinectStatus.Connected)
            {
                return;
            }
            
            // Get the depth frame
            using (DepthStreamData depthStreamData = gameInput.GetDepthStreamData())
            {
                // Sometimes we get a null frame back if no data is ready
                if (null != depthStreamData)
                {
                    DepthImageFrame frame = depthStreamData.DepthImageFrame;

                    // Reallocate values if necessary
                    if (null == GameInfo.DepthData || GameInfo.DepthData.Length != frame.PixelDataLength)
                    {
                        GameInfo.DepthData = new short[frame.PixelDataLength];
                        GameInfo.DepthImageFormat = frame.Format;
                        GameInfo.DepthFrameWidth = frame.Width;
                        GameInfo.DepthFrameHeight = frame.Height;
                    }

                    frame.CopyPixelDataTo(GameInfo.DepthData);

                    GameInfo.TankSkeletonMask = depthStreamData.TankSkeletonMask;
                    GameInfo.SoldierSkeletonMask = depthStreamData.SoldierSkeletonMask;
                    
                }
                else
                {
                    // Do nothing
                }
                
            }

            // Get the skeleton frame
            using (SkeletonStreamData skeletonStreamData = gameInput.GetSkeletonStreamData())
            {
                // Sometimes we get a null frame back if no data is ready
                if (null != skeletonStreamData)
                {
                    SkeletonFrame frame = skeletonStreamData.SkeletonFrame;

                    // Reallocate skeleton array if necessary
                    if (null == GameInfo.SkeletonData || GameInfo.SkeletonData.Length != frame.SkeletonArrayLength)
                    {
                        GameInfo.SkeletonData = new Skeleton[frame.SkeletonArrayLength];
                    }

                    frame.CopySkeletonDataTo(GameInfo.SkeletonData);

                    GameInfo.TankSkeletonIndex = skeletonStreamData.TankSkeletonIndex;
                    GameInfo.SoldierSkeletonIndex = skeletonStreamData.SoldierSkeletonIndex;
                }
                else
                {
                    // do nothing
                }

            }

            // Get player input
            GameInputInfo newGameInputInfo = gameInput.GetGameInput();
            if (newGameInputInfo != null)
                gameInputInfo = newGameInputInfo;

            return;
        }

        
    }
}
