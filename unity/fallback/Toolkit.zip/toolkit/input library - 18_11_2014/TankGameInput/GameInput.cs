﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Diagnostics;

using Microsoft.Xna.Framework;
using Microsoft.Kinect;

using TankGameInput.Extensions;


namespace TankGameInput
{

    /// <summary>
    /// Entry point for the TankGameInput library.
    /// </summary>
    public class GameInput : IDisposable
    {


        public GameInput()
        {

            skeletonData = null;
            
            InitFields();
            
            kinectChooser = new KinectChooser();
            playerDetector = new PlayerDetector();
            tankInputDetector = new TankInputDetector();
            soldierInputDetector = new SoldierInputDetector(kinectChooser);

            kinectChooser.AllFramesReady += new EventHandler<AllFramesReadyEventArgs>(kinectChooser_AllFramesReady);
            return;
        }


        public void Dispose()
        {
            if (skeletonFrame != null)
                skeletonFrame.Dispose();

            return;
        }

        
        /// <summary>
        /// Gets the current status of the Kinect.
        /// </summary>
        public KinectStatus KinectStatus { get { return kinectChooser.Status; } }

        /// <summary>
        /// Gets the CoordinateMapper which can map points between skeleton, color image, and depth image space.
        /// </summary>
        public CoordinateMapper CoordinateMapper
        {
            get { return kinectChooser.CoordinateMapper; }
        }

        /// <summary>
        /// Enables the color stream.
        /// </summary>
        public bool ColorStreamEnable
        {
            get { return kinectChooser.ColorStreamEnable; }
            set { kinectChooser.ColorStreamEnable = value; }
        }

        /// <summary>
        /// Enables the depth stream.
        /// </summary>
        public bool DepthStreamEnable
        {
            get { return kinectChooser.DepthStreamEnable; }
            set { kinectChooser.DepthStreamEnable = value; }
        }

        
        /// <summary>
        /// Retrieves data from the color stream. Will return null if no new data is present.
        /// </summary>
        /// <returns></returns>
        public ColorStreamData GetColorStreamData()
        {
            ColorStreamData data = new ColorStreamData();
            
            data.ColorImageFrame = colorFrame;
            colorFrame = null; // Assuming the user will dispose
            if (data.ColorImageFrame == null)
                return null;

            // If the sensor is not found, not running, or not connected, stop now
            if (kinectChooser.Status != KinectStatus.Connected)
                return null;

            return data;
        }

        /// <summary>
        /// Retrieves data from the depth stream. Will return null if no new data is present.
        /// </summary>
        /// <returns></returns>
        public DepthStreamData GetDepthStreamData()
        {
            DepthStreamData data = new DepthStreamData();
            
            data.DepthImageFrame = depthFrame;
            depthFrame = null; // Assuming the user will dispose
            if (data.DepthImageFrame == null)
                return null;

            data.TankSkeletonMask = tankSkeletonMask;
            data.SoldierSkeletonMask = soldierSkeletonMask;

            // If the sensor is not connected, stop now
            if (kinectChooser.Status != KinectStatus.Connected)
                return null;

            return data;
        }

        /// <summary>
        /// Retrieves data from the skeleton stream. Will return null if no new data is present.
        /// </summary>
        /// <returns></returns>
        public SkeletonStreamData GetSkeletonStreamData()
        {
            SkeletonStreamData data = new SkeletonStreamData();

            data.SkeletonFrame = skeletonFrame;
            skeletonFrame = null; // Assuming the user will dispose
            if (data.SkeletonFrame == null)
                return null;

            data.TankSkeletonIndex = tankSkeletonIndex;
            data.SoldierSkeletonIndex = soldierSkeletonIndex;

            // If the sensor is not connected, stop now
            if (kinectChooser.Status != KinectStatus.Connected)
                return null;

            return data;
        }

        /// <summary>
        /// Retrieves the current game input. Will return null if no new data is present.
        /// </summary>
        /// <returns></returns>
        public GameInputInfo GetGameInput()
        {
            GameInputInfo inputInfoRet = inputInfo;
            inputInfo = null; // We release control to the user just like the Kinect data streams do

            // If the sensor is not connected, stop now
            if (kinectChooser.Status != KinectStatus.Connected)
                return null;

            return inputInfoRet;
        }



        void InitFields()
        {
            inputInfo = new GameInputInfo();

            tankSkeletonIndex = -1;
            soldierSkeletonIndex = -1;

            tankSkeletonMask = -1;
            soldierSkeletonMask = -1;

            return;
        }


        
        void kinectChooser_AllFramesReady(object sender, AllFramesReadyEventArgs e)
        {

            // Save color frame
            if (colorFrame != null)
                colorFrame.Dispose();

            colorFrame = e.OpenColorImageFrame();

            // Save depth frame
            if (depthFrame != null)
                depthFrame.Dispose();

            depthFrame = e.OpenDepthImageFrame();

            // Save skeleton frame
            if (skeletonFrame != null)
                skeletonFrame.Dispose();
            
            skeletonFrame = e.OpenSkeletonFrame();

            
            // Save skeleton data
            if (skeletonFrame != null)
            {
                // Reallocate skeleton data if necessary
                if (skeletonData == null || skeletonData.Length != skeletonFrame.SkeletonArrayLength)
                {
                    skeletonData = new Skeleton[skeletonFrame.SkeletonArrayLength];
                }

                // Copy skeleton data
                skeletonFrame.CopySkeletonDataTo(skeletonData);
            }
            else
            {
                // do nothing
            }

            // Save input info
            CalculateInputInfo();

            return;
        }


        /// <summary>
        /// Calculates the input info based on the skeleton data.
        /// </summary>
        void CalculateInputInfo()
        {
            
            // Check if we have any skeleton data
            if (skeletonFrame == null || skeletonData == null)
            {
                inputInfo = null;

                tankSkeletonMask = -1;
                soldierSkeletonMask = -1;

                tankSkeletonIndex = -1;
                soldierSkeletonIndex = -1;
                
                return;
            }


            // Determine the skeletons that are sitting //
            Posture[] postures = Array.ConvertAll(skeletonData, x => SittingDetector.DetectSitting(x));


            // Get tank and soldier skeletons //
            // These will be the closest standing and sitting skeletons to the Kinect

            playerDetector.AddSkeletons(skeletonData, postures);

            bool isTankAvailable = playerDetector.IsTankAvailable;
            bool isSoldierAvailable = playerDetector.IsSoldierAvailable;

            Skeleton tankSkeleton = isTankAvailable ? skeletonData[playerDetector.TankSkeletonIndex] : null;
            Skeleton soldierSkeleton = isSoldierAvailable ? skeletonData[playerDetector.SoldierSkeletonIndex] : null;

            
            // Create the new game input info //

            // Tank info
            tankInputDetector.AddSkeleton(tankSkeleton);

            // Soldier info
            soldierInputDetector.AddSkeleton(soldierSkeleton, tankSkeleton);

            // Set the new input info //
            inputInfo = new GameInputInfo(skeletonFrame.Timestamp, skeletonFrame.FrameNumber, tankInputDetector.TankInfo, soldierInputDetector.SoldierInfo);

            // Set the tank and soldier skeletons for people to use
            if (isTankAvailable)
            {
                tankSkeletonIndex = playerDetector.TankSkeletonIndex;
                tankSkeletonMask = playerDetector.TankSkeletonIndex + 1;
            }
            else
            {
                tankSkeletonIndex = -1;
                tankSkeletonMask = -1;
            }

            if (isSoldierAvailable)
            {
                soldierSkeletonIndex = playerDetector.SoldierSkeletonIndex;
                soldierSkeletonMask = playerDetector.SoldierSkeletonIndex + 1;
            }
            else
            {
                soldierSkeletonIndex = -1;
                soldierSkeletonMask = -1;
            }

            return;
        }


        readonly KinectChooser kinectChooser;
        readonly PlayerDetector playerDetector;
        readonly TankInputDetector tankInputDetector;
        readonly SoldierInputDetector soldierInputDetector;


        // Kinect data storage
        ColorImageFrame colorFrame;
        DepthImageFrame depthFrame;
        SkeletonFrame skeletonFrame;
        Skeleton[] skeletonData; // skeleton data for the current frame.


        // Player input information
        GameInputInfo inputInfo;

        int tankSkeletonMask;
        int soldierSkeletonMask;

        int tankSkeletonIndex;
        int soldierSkeletonIndex;

    }
}
